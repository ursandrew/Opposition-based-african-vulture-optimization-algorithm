%%% African Vulture Optimization Algorithm %%%
%%% Opposition-Based African Vulture Optimization Algorithm %%%

clc;
clear all;
close all;

N=30; % Number of Search Agents
Function_name ='F1'; % F1-F5
MaxIT=500; % Maximum number of Iterations

[lb,ub,dim,fobj]=benchmarks(Function_name);

[Best_Score,Best_Pos,Convergence_curve]=OBAVOA(N,MaxIT,lb,ub,dim,fobj);
[Best_Score1,Best_Pos1,Convergence_curve1]=AVOA(N,MaxIT,lb,ub,dim,fobj);

display(['The best fitness of OBAVOA is: ', num2str(Best_Score)]);
display(['The best fitness of AVOA is: ', num2str(Best_Score1)]);

semilogy(Convergence_curve,'LineWidth',2);
hold on
semilogy(Convergence_curve1,'LineWidth',2);

xlabel('Iterations');
ylabel('Best fitness obtained so far');
legend('OBAVOA','AVOA');