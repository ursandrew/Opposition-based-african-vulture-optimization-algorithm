
function [Best_Score,Best_Position,CG_curve]=OBAVOA(N,T,lb,ub,dim,fobj)

L1=0.8;
P1=0.6;
P2=0.6;
P3=0.6;
w=2;

X=initialization(N,dim,ub,lb);

for i=1:N
    fitness(i)=fobj(X(i,:));
end

z1=ones(1,round(N*L1));
z2=2*ones(1,N-round(N*L1));
Z=[z1,z2];
rd=randperm(N);
Z=Z(rd);
[V,ind]=sort(fitness);
   Best_Vulture1=X(ind(1),:);
   X1=X(ind,:);
   Vd=V(1)-V;
   f=find(Vd~=0);
   if numel(f)~=0
       Best_Vulture2=X1(f(1),:);
   else
       f(1)=2;
       Best_Vulture2=X1(f(1),:);
   end
   CG_curve(1)=V(1);
   Pbest=Best_Vulture1;
for itr=2:T
   for i=1:N
       rd=randperm(N);
       if Z(rd(1))==1
           R=Best_Vulture1;
       else
           R=Best_Vulture2;
       end
       h=4*(rand-0.5);
       t=h*((sin((pi/2)*(itr/T)))^w+cos((pi/2)*(itr/T))-1);
       F=(2*rand+1)*2*(rand-0.5)*(1-(itr/T))+t;
       if abs(F)>=1
           if P1>rand
               D=abs(2*rand*R-X(i,:));
               X(i,:)=R-D*F;
           else
               X(i,:)=R-F+rand*((ub-lb)*rand+lb);
           end
       else
           if abs(F)>=0.5
               if P2>rand
                   d=R-X(i,:);
                   D=abs(2*rand*R-X(i,:));
                   X(i,:)=D*(F+rand)-d;
               else
                  S1=R.*(rand*X(i,:)).*cos(X(i,:))/(2*pi);
                  S2=R.*(rand*X(i,:)).*sin(X(i,:))/(2*pi);
                  X(i,:)=R-(S1+S2);
               end
           else
               if P3>rand
                   A1=Best_Vulture1-((Best_Vulture1.*X(i,:))./(Best_Vulture1.*(X(i,:).^2)))*F;
                   A2=Best_Vulture2-((Best_Vulture2.*X(i,:))./(Best_Vulture2.*(X(i,:).^2)))*F;
                   X(i,:)=0.5*(A1+A2);
               else
                  d=R-X(i,:);
                  X(i,:)=R-abs(d).*F.*Levy(dim);
               end
           end
       end
   end
   
   for i=1:N
      if rand<0.4
        X(i,:)=X(i,:).*(1+randn(1,1));
      end
   end
  
   X=min(X,ub);
   X=max(X,lb);
   
   for i=1:N
       D(i,:)=min(X(i,:))+max(X(i,:))-X(i,:);
       Flag4ub=D(i,:)>ub;
       Flag4lb=D(i,:)<lb;
       D(i,:)=(D(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
   end
   
   for i=1:N
       op_fitness=fobj(D(i,:));
       or_fitness=fobj(X(i,:));
        if op_fitness<or_fitness
            X(i,:)=D(i,:);
            fitness(i)=op_fitness;
        else
            fitness(i)=or_fitness;
        end
        
  [V,ind]=sort(fitness); 
  Best_Vulture1=X(ind(1),:);
   X1=X(ind,:);
   Vd=V(1)-V;
   f=find(Vd~=0);
   if numel(f)~=0
       Best_Vulture2=X1(f(1),:);
   else
       f(1)=2;
       Best_Vulture2=X1(f(1),:);
   end 
   
   if V(1)<CG_curve(itr-1)
       Pbest=Best_Vulture1;
       CG_curve(itr)=V(1);
   else
       Best_Vulture1=Pbest;
       CG_curve(itr)=CG_curve(itr-1);
   end

   end
end
Best_Score=CG_curve(end);
Best_Position=Pbest;
end

function o=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;v=randn(1,d);step=u./abs(v).^(1/beta);
o=step;
end

function [X]=initialization(N,dim,up,down)
% rng('default');
if size(up,1)==1
    X=rand(N,dim).*(up-down)+down;
end
if size(up,1)>1
    for i=1:dim
        high=up(i);low=down(i);
        X(:,i)=rand(1,N).*(high-low)+low;
    end
end
end